package com.banco.apibanco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiBancoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiBancoApplication.class, args);
	}

}
