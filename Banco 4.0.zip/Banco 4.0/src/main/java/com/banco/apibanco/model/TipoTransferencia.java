package com.banco.apibanco.model;

public enum TipoTransferencia {

	TED, DOC;

}
