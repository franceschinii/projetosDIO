package com.banco.apibanco.servico;

public interface ContaServico {

}
